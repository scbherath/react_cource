import React from 'react'

const Counter = ({value}) => {
    return (        
        <div >
            <p class="text-danger"> <h1>{value}</h1> </p>               
        </div>         
    )
}

export default Counter;